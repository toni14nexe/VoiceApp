<?php
    //host = 'localhost'
    $db_host = 'localhost';
    //user_root = 'root'
    $db_user = 'id18493485_root';
    //pass_host = '' ili 'CD4}T7%PlYIKe9d*'
    $db_pass = 'CD4}T7%PlYIKe9d*';
    //dbname = 'zavrsni'
    $db_name = 'id18493485_zavrsni';
    
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if($conn->connect_error){
        die("Connection Failed!".$conn->connect_error);
    }

    $mysqli = NEW MySQLi($db_host, $db_user, $db_pass, $db_name);

    $db = new PDO('mysql:host=localhost;dbname=' . $db_name . ';charset=utf8', $db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $dbu = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    $db = new PDO('mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8',$db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $link = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    $pdo = new PDO('mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8',$db_user, $db_pass);
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if($conn->connect_error){
        die("Connection Failed!".$conn->connect_error);
    }
    
    $firstname = $_GET['firstname'];
    $lastname = $_GET['lastname'];
    $email = $_GET['email'];
    $password = $_GET['password'];
    $verificationLink = $_GET['verificationLink'];
    
    $stmt = $pdo->prepare("SELECT * FROM VoiceAppUsers WHERE email=?");
    $stmt->execute([$email]); 
    $user = $stmt->fetch();
    if ($user) {
        header("Location: http://127.0.0.1:5173/cookieUserExist");
    } else {
        $sql = "INSERT INTO `VoiceAppUsers`(`firstname`, `lastname`, `email`, `password`, `verificationLink`) VALUES ('$firstname','$lastname','$email','$password','$verificationLink')";
        mail($email,"VoiceApp verification",$msg);
        if ($conn->query($sql) === TRUE) {
            $msg = "To verify you VoiceApp account click on the link below:\nhttps://toni14nexe.000webhostapp.com/VoiceApp/verification.php?verificationLink=" . $verificationLink;
            $msg = wordwrap($msg,70);
            mail($email,"VoiceApp verification",$msg);
            header("Location: http://127.0.0.1:5173/cookieRegistrationSuceed");
            } else {
                header("Location: http://127.0.0.1:5173/cookieError");
            }
        }

    $conn->close();
?>