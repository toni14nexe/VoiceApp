<?php
    //host = 'localhost'
    $db_host = 'localhost';
    //user_root = 'root'
    $db_user = 'id18493485_root';
    //pass_host = '' ili 'CD4}T7%PlYIKe9d*'
    $db_pass = 'CD4}T7%PlYIKe9d*';
    //dbname = 'zavrsni'
    $db_name = 'id18493485_zavrsni';

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if($conn->connect_error){
        die("Connection Failed!".$conn->connect_error);
    }

    $mysqli = NEW MySQLi($db_host, $db_user, $db_pass, $db_name);

    $db = new PDO('mysql:host=localhost;dbname=' . $db_name . ';charset=utf8', $db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $dbu = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    $db = new PDO('mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8',$db_user, $db_pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $link = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    $pdo = new PDO('mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8',$db_user, $db_pass);
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if($conn->connect_error){
        die("Connection Failed!".$conn->connect_error);
    }
    
    $password = $_GET['password'];
    $verificationLink = $_GET['verificationLink'];
    $newVerificationLink = $_GET['newVerificationLink'];
    
    $stmt = $pdo->prepare("SELECT * FROM VoiceAppUsers WHERE verificationLink=?");
    $stmt->execute([$verificationLink]); 
    $user = $stmt->fetch();
    if ($user) {
        $sql = "UPDATE VoiceAppUsers SET verificationLink='$newVerificationLink', verified='1', password='$password' WHERE verificationLink='$verificationLink'";
        if ($conn->query($sql) === TRUE) {
            header("Location: http://127.0.0.1:5173/cookieNewPasswordSuceed");
        } else {
            header("Location: http://127.0.0.1:5173/cookieError");
        }
    } else {
        header("Location: http://127.0.0.1:5173/cookieError");
    }
    
    $conn->close();
?>